package com.example.appdenews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    var isPlayer1 = true
    var gameEnd = false

    private lateinit var top: ImageView
    private lateinit var topStar: ImageView
    private lateinit var topEnd: ImageView


    private lateinit var center: ImageView
    private lateinit var centerStar: ImageView
    private lateinit var centerEnd: ImageView

    private lateinit var bottom: ImageView
    private lateinit var bottomStar: ImageView
    private lateinit var bottomEnd: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        center = findViewById(R.id.center)
        centerStar = findViewById(R.id.centerStar)
        centerEnd = findViewById(R.id.centerend)

        top = findViewById(R.id.top)
        topStar = findViewById(R.id.topStar)
        topEnd = findViewById(R.id.topEnd)

        bottom = findViewById(R.id.bottom)
        bottomStar = findViewById(R.id.bottomStar)
        bottomEnd = findViewById(R.id.bottomEnd)

        val reset: button =findViewById(R.id.button_reset)
        reset.setOnClickListener {

            resetBox(top)
            resetBox(topStar)
            resetBox(topEnd)

            resetBox(center)
            resetBox(centerStar)
            resetBox(centerEnd)

            resetBox(bottom)
            resetBox(bottomStar)
            resetBox(bottomEnd)
        }

        configureBox(top)
        configureBox(topStar)
        configureBox(topEnd)

        configureBox(center)
        configureBox(centerStar)
        configureBox(centerEnd)

        configureBox(bottom)
        configureBox(bottomStar)
        configureBox(bottomEnd)

    }
    private fun resetBox(box: ImageView) {
        box.setImageDrawable(null)
        box.tag = null
        isPlayer1 = true
        gameEnd = false

    }

    private fun configureBox(box: ImageView) {
        box.setOnClickListener {
            if (box.tag == null && !gameEnd) {
                if (isPlayer1) {
                    box.setImageResource(R.drawable.baseline_add_circle_24)
                    isPlayer1 = false
                    box.tag = 1
                } else {
                    box.setImageResource(R.drawable.baseline_close_24)
                    isPlayer1 = true
                    box.tag = 2
                }

                if (PlayerWin(1)) {
                    Toast.makeText(this@MainActivity, "Player 1 venceu!", Toast.LENGTH_SHORT).show()
                    gameEnd = true
                } else if(PlayerWin(2)){
                    Toast.makeText(this@MainActivity, "Player 2 venceu!", Toast.LENGTH_SHORT).show()
                    gameEnd = true
                }
            }
        }
    }
    private fun PlayerWin(value: Int) : Boolean {
        if ( (top.tag == value && center.tag == value && bottom.tag == value)  ||
            (topStar.tag == value && centerStar.tag == value && bottomStar.tag == value) ||
            (topEnd.tag == value && centerEnd.tag == value && bottomEnd.tag == value) ||

            (topStar.tag == value && top.tag == value && topEnd.tag == value) ||
            (centerStar.tag == value && center.tag == value && centerEnd.tag == value) ||
            (bottomStar.tag == value && bottom.tag == value && bottomEnd.tag == value) ||

            (topStar.tag == value && center.tag == value && bottomEnd.tag == value) ||
            (topEnd.tag == value && center.tag == value && bottomStar.tag == value)

                 ) {
            return true
        }
        return false
    }
}